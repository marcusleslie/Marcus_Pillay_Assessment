﻿namespace CommentarySentimentAnalyzer
{
    public static class Constants
    {
        public const string PositiveSentimentLabel = "POSITIVE";
        public const string NeutralSentimentLabel = "NEUTRAL";
        public const string NegativeSentimentLabel = "NEGATIVE";
    }
}
