﻿//for count code
using System;

using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace CommentarySentimentAnalyzer
{
    public class SentimentAnalysisModel
    {
        private readonly string _file;

        public SentimentAnalysisModel(string file)
        {
            _file = file;
        }

        public string analyzeSentiment()
        {
            var statementSentimentCount = new Dictionary<string, int>();
            ReportHelper.initializeSentimentCounters(statementSentimentCount);

            var statements = File.ReadAllLines(_file);
            
            foreach (var statement in statements)
            {        
                // rule: happy word exists
                if (Regex.IsMatch(statement, @"\bhappy\b"))
                    statementSentimentCount[Constants.PositiveSentimentLabel] =statementSentimentCount[Constants.PositiveSentimentLabel] + 1;
                // rule: exclamation mark symbol occurs at least once
                if (statement.Count(s => s == '!') >= 1)
                    statementSentimentCount[Constants.PositiveSentimentLabel] =statementSentimentCount[Constants.PositiveSentimentLabel] + 1;
                
                // rule: unhappy word exists
                if (statement.Contains("unhappy"))
                    statementSentimentCount[Constants.NegativeSentimentLabel] = statementSentimentCount[Constants.NegativeSentimentLabel] + 1;
                // rule: question mark symbol occurs more that once
                if (statement.Count(s => s == '?') >= 2)
                    statementSentimentCount[Constants.NegativeSentimentLabel] = statementSentimentCount[Constants.NegativeSentimentLabel] + 1;
                // rule: sad word exists
                if (statement.Contains("sad"))
                    statementSentimentCount[Constants.NegativeSentimentLabel] = statementSentimentCount[Constants.NegativeSentimentLabel] + 1;
                // rule: complaint word exists
                if (statement.Contains("complaint"))
                     {
                     statementSentimentCount[Constants.NegativeSentimentLabel] = statementSentimentCount[Constants.NegativeSentimentLabel] + 1;
                       // rule: email address and the word (or part of the word) complaint exist
                        if (ValidateEmail(statement))
                        statementSentimentCount[Constants.NegativeSentimentLabel] = statementSentimentCount[Constants.NegativeSentimentLabel] + 1;
                     }                          
            }

            var finalSentiment = determineSentiment(statementSentimentCount);

            return (finalSentiment);
        }

        /// <summary>
        /// Determine the final sentiment of the commentary based on the sentiment
        /// of the individual statements within the commentary
        /// </summary>
        /// <param name="statementSentimentCount">Sentiments for each statement in a file</param>
        /// <returns>Returns the final sentiment</returns>
        private string determineSentiment(Dictionary<string, int> statementSentimentCount)
        {
            var finalSentiment = string.Empty;

            if (statementSentimentCount[Constants.PositiveSentimentLabel] > statementSentimentCount[Constants.NegativeSentimentLabel])
            {
                finalSentiment = Constants.PositiveSentimentLabel;
            }
            else if (statementSentimentCount[Constants.PositiveSentimentLabel] < statementSentimentCount[Constants.NegativeSentimentLabel])
            {
                finalSentiment = Constants.NegativeSentimentLabel;
            }
            else
            {
                finalSentiment = Constants.NeutralSentimentLabel;
            }

            return (finalSentiment);
        }

        //Check if string contains an email address
        public bool ValidateEmail(string str)
        {
            return Regex.IsMatch(str, @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
        }
       
    }
}
